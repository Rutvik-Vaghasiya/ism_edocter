
import { Route, Routes } from 'react-router-dom';
 import { AdminLogin } from './Admin/AdminLogin';

// import { Template } from "./Template";

// import ComanPages from "./ComanPages";

// import { Login } from './Login';
 import { Navbar } from './Navbar';
// import DrawerAppBar from './TestMui/Drower';
// import PrimarySearchAppBar from './TestMui/NavbarMui1';
// import { Sidebar } from './TestMui/Sidebar';
import { Home } from './DashBoard/Home';
import { About } from './DashBoard/About';
import { ContactUs } from './DashBoard/ContactUs';
import { AdminMain } from './Admin/Components/AdminMain';


function App() {


  return (
    // the flow of app starts here
    <div>

      {/* <ComanPages/> */}
      {/* MUI Nav */}
      {/* <DrawerAppBar/>    */}
      {/* <PrimarySearchAppBar/> */}
      {/* <Sidebar/> */}
      {/* <Template/> */}
      <Navbar />
      {/* <AdminLogin/> */}
      <AdminMain/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/login' element={<AdminLogin/>}/>
        <Route path='/about' element={<About/>}></Route>
        <Route path='/contact' element={<ContactUs/>}/>
      </Routes> 
   
    </div>
  );
}

export default App;
