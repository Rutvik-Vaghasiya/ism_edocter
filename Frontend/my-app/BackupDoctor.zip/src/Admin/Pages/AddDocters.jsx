import React from 'react'

export const AddDocters = () => {
  return (
    <div>AddDocters</div>
  )
}
