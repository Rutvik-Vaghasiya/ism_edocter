import React from 'react'
import { AdminNavbar } from './AdminNavbar'


export const AdminMain = () => {
  return (
    <div >
        <AdminNavbar/>
    </div>
  )
}
