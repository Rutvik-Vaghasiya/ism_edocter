import { FormControlLabel } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom';
import { MaterialUISwitch } from '../../DashBoard/ThemBtn';

export const AdminNavbar = () => {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">&nbsp;
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                &nbsp;
                <div className="collapse navbar-collapse" id="navbarTogglerDemo03">
                    <Link className="navbar-brand" to="/">HOSPITAL</Link>

                    <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Doctors
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Add Doctor</a>
                                <a class="dropdown-item" href="#">All Doctors</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Patients
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Add Patient</a>
                                <a class="dropdown-item" href="#">All Patient</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Something else here</a>
                            </div>
                        </li>

                        <li className="nav-item">
                            <Link className="nav-link" to="/login">Appointments</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/login">Calendar</Link>
                        </li>
                    </ul>
                </div>
                <div>
                    <FormControlLabel
                        control={<MaterialUISwitch sx={{ m: 1 }} defaultChecked />}
                    // label="Theam Mode"
                    />
                </div>
                <form className="form-inline my-2 my-lg-0">
                    <input className="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" />
                    <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>&nbsp;

                &nbsp;
            </nav>
        </div>
    )
}
