import React from 'react'

export const DashbordAdmin = () => {
  return (
    <div>DashbordAdmin</div>
  )
}
