import React from 'react';
import '../css/Contect.css';

export const ContactUs = () => {
    return (
        <>
            <div className='mapstyale'>
                ContactUs</div>
            <div className='sst'>
                {/* <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7557115.26032612!2d66.83145338048793!3d22.35371623966016!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959051f5f0ef795%3A0x861bd887ed54522e!2sGujarat!5e0!3m2!1sen!2sin!4v1669874837991!5m2!1sen!2sin" allowFullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> */}
            </div>

        </>
    )
}
