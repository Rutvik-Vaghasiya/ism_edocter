import React from "react";

export const AdmAddDr = () => {
  return <div>AdmAddDr</div>;
};
