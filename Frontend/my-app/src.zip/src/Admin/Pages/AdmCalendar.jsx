import React from 'react'

export const AdmCalendar = () => {
  return (
    <div>AdmCalendar</div>
  )
}
