import React from 'react'

export const AdmAppointment = () => {
  return (
    <div>AdmAppointment</div>
  )
}
