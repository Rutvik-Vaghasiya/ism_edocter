import React from 'react'

export const AdmContact = () => {
  return (
    <div>AdmContact</div>
  )
}
