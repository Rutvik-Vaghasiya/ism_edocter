import React from 'react'

export const PtQuery = () => {
  return (
    <div>PtQuery</div>
  )
}
