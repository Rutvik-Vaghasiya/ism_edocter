import React from "react";

export const PtDashbord = () => {
  return (
    <div>
      <h1>DashBord Patients Profiles</h1>
    </div>
  );
};
