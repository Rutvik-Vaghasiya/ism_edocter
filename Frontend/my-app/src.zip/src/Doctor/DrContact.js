import React from 'react'

export const DrContact = () => {
  return (
    <div>DrContact</div>
  )
}
