import React from "react";

export const DrDashbord = () => {
  return (
    <div>
      <h1>WELECOME DOCTORS PROFILE</h1>
    </div>
  );
};
